# godot-3d-outline
An easy to use 3d outline shader which can be enabled and disabled through a simple parameter.

# How to use?
Simply add the outline.material as the next_pass of the material to which you wannt to apply the outline.
_If you don't need any exsamples you can delete the TEST folder. Othwise the exsamples in there could be helpful to you._

# What's the outline.shader capeable of?
- **enable:** you can always turn the outline on or off (useful for marking the object a player is pointing at). For an exsample implementation checkout the Toggle Outline.gd file.
- **color:** choose the color your outline needs
- **thickness:** adjust the strength of the outline
